package Proyecto;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Manejo.Controlador;
import Modelo.Estudiante;

import javax.swing.UIManager;
import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import net.miginfocom.swing.MigLayout;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JRadioButton;
import javax.naming.ldap.Rdn;
import javax.swing.ButtonGroup;
import javax.swing.JTabbedPane;
import java.awt.Window.Type;

public class Principal extends JFrame {

	private JPanel contentPane;
	private JTextField txtnombres;
	private JTextField txtape;
	private final ButtonGroup bg1 = new ButtonGroup();
	private final ButtonGroup bg2 = new ButtonGroup();
	private final ButtonGroup bg3 = new ButtonGroup();
	private final ButtonGroup bg4 = new ButtonGroup();
	private final ButtonGroup bg5 = new ButtonGroup();
	private final ButtonGroup bg6 = new ButtonGroup();
	private final ButtonGroup bg7 = new ButtonGroup();
	private final ButtonGroup bg8 = new ButtonGroup();
	private final ButtonGroup bg9 = new ButtonGroup();
	private final ButtonGroup bg10 = new ButtonGroup();
	private final ButtonGroup bg11 = new ButtonGroup();
	private final ButtonGroup bg12 = new ButtonGroup();
	private final ButtonGroup bg25 = new ButtonGroup();
	private final ButtonGroup bg26 = new ButtonGroup();
	private final ButtonGroup bg27 = new ButtonGroup();
	private final ButtonGroup bg28 = new ButtonGroup();
	private final ButtonGroup bg29 = new ButtonGroup();
	private final ButtonGroup bg30 = new ButtonGroup();
	private final ButtonGroup bg31 = new ButtonGroup();
	private final ButtonGroup bg32 = new ButtonGroup();
	private final ButtonGroup bg33 = new ButtonGroup();
	private final ButtonGroup bg34 = new ButtonGroup();
	private final ButtonGroup bg35 = new ButtonGroup();
	private final ButtonGroup bg36 = new ButtonGroup();
	private final ButtonGroup bg37 = new ButtonGroup();
	private final ButtonGroup bg38 = new ButtonGroup();
	private final ButtonGroup bg39 = new ButtonGroup();
	private final ButtonGroup bg40 = new ButtonGroup();
	private final ButtonGroup bg41 = new ButtonGroup();
	private final ButtonGroup bg42 = new ButtonGroup();
	private final ButtonGroup bg43 = new ButtonGroup();
	private final ButtonGroup bg44 = new ButtonGroup();
	private final ButtonGroup bg13 = new ButtonGroup();
	private final ButtonGroup bg14 = new ButtonGroup();
	private final ButtonGroup bg15 = new ButtonGroup();
	private final ButtonGroup bg16 = new ButtonGroup();
	private final ButtonGroup bg17 = new ButtonGroup();
	private final ButtonGroup bg18 = new ButtonGroup();
	private final ButtonGroup bg19 = new ButtonGroup();
	private final ButtonGroup bg20 = new ButtonGroup();
	private final ButtonGroup bg21 = new ButtonGroup();
	private final ButtonGroup bg22 = new ButtonGroup();
	private final ButtonGroup bg23 = new ButtonGroup();
	private final ButtonGroup bg24 = new ButtonGroup();
	private JRadioButton rd1p1;
	private JRadioButton rd2p1;
	private JRadioButton rd1p2;
	private JRadioButton rd2p4;
	private JRadioButton rd1p5;
	private JRadioButton rd2p6;
	private JRadioButton rd1p7;
	private JRadioButton rd2p7;
	private JRadioButton rd1p8;
	private JRadioButton rd2p8;
	private JRadioButton rd2p2;
	private JRadioButton rd1p3;
	private JRadioButton rd2p3;
	private JRadioButton rd1p4;
	private JRadioButton rd2p5;
	private JRadioButton rd1p6;
	private JRadioButton rd2p9;
	private JRadioButton rd1p9;
	private JRadioButton rd1p10;
	private JRadioButton rd2p10;
	private JRadioButton rd1p11;
	private JRadioButton rd2p11;
	private JRadioButton rd1p12;
	private JRadioButton rd2p12;
	private JRadioButton rd1p13;
	private JRadioButton rd2p13;
	private JRadioButton rd1p14;
	private JRadioButton rd2p14;
	private JRadioButton rd1p15;
	private JRadioButton rd2p15;
	private JRadioButton rd1p16;
	private JRadioButton rd2p16;
	private JRadioButton rd1p17;
	private JRadioButton rd2p17;
	private JRadioButton rd1p18;
	private JRadioButton rd2p18;
	private JRadioButton rd1p19;
	private JRadioButton rd2p19;
	private JRadioButton rd1p20;
	private JRadioButton rd2p20;
	private JRadioButton rd1p21;
	private JRadioButton rd2p21;
	private JRadioButton rd1p22;
	private JRadioButton rd1p23;
	private JRadioButton rd2p23;
	private JRadioButton rd1p24;
	private JRadioButton rd2p24;
	private JRadioButton rd2p22;
	private JRadioButton rb1p25;
	private JRadioButton rb2p25;
	private JRadioButton rb1p26;
	private JRadioButton rb2p26;
	private JRadioButton rb1p27;
	private JRadioButton rb2p27;
	private JRadioButton rb1p28;
	private JRadioButton rb2p28;
	private JRadioButton rb1p29;
	private JRadioButton rb2p29;
	private JRadioButton rb1p30;
	private JRadioButton rb2p30;
	private JRadioButton rb1p31;
	private JRadioButton rb2p31;
	private JRadioButton rb1p32;
	private JRadioButton rb2p32;
	private JRadioButton rb1p33;
	private JRadioButton rb2p33;
	private JRadioButton rb1p34;
	private JRadioButton rb2p34;
	private JRadioButton rb1p35;
	private JRadioButton rb1p36;
	private JRadioButton rb2p35;
	private JRadioButton rb2p36;
	private JRadioButton rb1p37;
	private JRadioButton rb2p37;
	private JRadioButton rb1p38;
	private JRadioButton rb2p38;
	private JRadioButton rb1p39;
	private JRadioButton rb2p39;
	private JRadioButton rb1p40;
	private JRadioButton rb2p40;
	private JRadioButton rb1p41;
	private JRadioButton rb2p41;
	private JRadioButton rb1p42;
	private JRadioButton rb2p42;
	private JRadioButton rb1p43;
	private JRadioButton rb2p43;
	private JRadioButton rb1p44;
	private JRadioButton rb2p44;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			UIManager.setLookAndFeel("com.jtattoo.plaf.acryl.AcrylLookAndFeel");
		} catch (Throwable e) {
			e.printStackTrace();
		}
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Principal frame = new Principal();
					frame.setVisible(true);
					frame.setExtendedState(Principal.MAXIMIZED_BOTH);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Principal() {
		setTitle("SISTEMA EXPERTO");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1068, 797);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);

		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.WEST);
		panel.setLayout(new MigLayout("", "[135px,grow,center][grow,center][grow][grow]",
				"[20px,grow][grow,center][grow][grow][grow][grow]"));

		JLabel lblDatosDelAlumno = new JLabel("Datos del Estudiante");
		lblDatosDelAlumno.setFont(new Font("Segoe UI", Font.BOLD, 14));
		panel.add(lblDatosDelAlumno, "cell 0 0 2 1,alignx center,aligny center");

		JLabel lblNewLabel = new JLabel("Nombres:");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(lblNewLabel, "flowx,cell 0 1,growx,aligny center");

		txtnombres = new JTextField();
		panel.add(txtnombres, "cell 1 1,growx,aligny center");
		txtnombres.setColumns(10);

		JLabel lblApellidos = new JLabel("Apellidos:");
		lblApellidos.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(lblApellidos, "cell 0 2,grow");

		txtape = new JTextField();
		panel.add(txtape, "cell 1 2,growx,aligny center");
		txtape.setColumns(10);

		JLabel lblNewLabel_1 = new JLabel("Grado:");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(lblNewLabel_1, "cell 0 3,growx,aligny center");

		JComboBox cmbGrado = new JComboBox();
		cmbGrado.setModel(new DefaultComboBoxModel(
				new String[] { "SELECCIONE UNA RESPUESTA", "Segundo", "Tercero", "Cuarto ", "Quinto" }));
		panel.add(cmbGrado, "cell 1 3,growx,aligny center");

		JLabel lblNewLabel_2 = new JLabel("Paralelo:");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(lblNewLabel_2, "cell 0 4,growx,aligny center");

		JComboBox cmbParalelo = new JComboBox();
		cmbParalelo.setModel(new DefaultComboBoxModel(new String[] { "SELECCIONE UNA RESPUESTA", "A", "B", "C", "D" }));
		panel.add(cmbParalelo, "cell 1 4,growx,aligny center");

		JButton btnNewButton = new JButton("VALIDAR");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String nom = txtnombres.getText();
				String ape = txtape.getText();

				int p1 = 0, p2 = 0, p3 = 0, p4 = 0, p5 = 0, p6 = 0, p7 = 0, p8 = 0, p9 = 0, p10 = 0, p11 = 0, p12 = 0,
						p13 = 0, p14 = 0, p15 = 0, p16 = 0, p17 = 0, p18 = 0, p19 = 0, p20 = 0, p21 = 0, p22 = 0,
						p23 = 0, p24 = 0;

				int pv1 = 0, pv2 = 0, pv3 = 0, pv4 = 0, pv5 = 0, pv6 = 0, pv7 = 0, pv8 = 0, pv9 = 0, pv10 = 0, pv11 = 0,
						pv12 = 0, pv13 = 0, pv14 = 0, pv15 = 0, pv16 = 0, pv17 = 0, pv18 = 0, pv19 = 0, pv20 = 0;

				if (rd1p1.isSelected() == true) {
					p1 = 1;
				} else if (rd2p1.isSelected()) {
					p1 = 0;
				}

				if (rd1p2.isSelected() == true) {
					p2 = 1;
				} else if (rd1p2.isSelected()) {
					p2 = 0;
				}

				if (rd1p3.isSelected() == true) {
					p3 = 1;
				} else if (rd2p3.isSelected()) {
					p3 = 0;
				}

				if (rd1p4.isSelected() == true) {
					p4 = 1;
				} else if (rd2p4.isSelected()) {
					p4 = 0;
				}

				if (rd1p5.isSelected() == true) {
					p5 = 1;
				} else if (rd2p5.isSelected()) {
					p5 = 0;
				}

				if (rd1p6.isSelected() == true) {
					p6 = 1;
				} else if (rd2p6.isSelected()) {
					p6 = 0;
				}
				if (rd1p7.isSelected() == true) {
					p7 = 1;
				} else if (rd2p7.isSelected()) {
					p7 = 0;
				}
				if (rd1p8.isSelected() == true) {
					p8 = 1;
				} else if (rd2p8.isSelected()) {
					p8 = 0;
				}
				if (rd1p9.isSelected() == true) {
					p9 = 1;
				} else if (rd2p9.isSelected()) {
					p9 = 0;
				}
				if (rd1p10.isSelected() == true) {
					p10 = 1;
				} else if (rd2p10.isSelected()) {
					p10 = 0;
				}

				if (rd1p11.isSelected() == true) {
					p11 = 1;
				} else if (rd2p11.isSelected()) {
					p11 = 0;
				}
				if (rd1p12.isSelected() == true) {
					p12 = 1;
				} else if (rd2p12.isSelected()) {
					p12 = 0;
				}
				if (rd1p13.isSelected() == true) {
					p13 = 1;
				} else if (rd2p13.isSelected()) {
					p13 = 0;
				}
				if (rd1p14.isSelected() == true) {
					p14 = 1;
				} else if (rd2p14.isSelected()) {
					p14 = 0;
				}
				if (rd1p15.isSelected() == true) {
					p15 = 1;
				} else if (rd2p15.isSelected()) {
					p15 = 0;
				}
				if (rd1p16.isSelected() == true) {
					p16 = 1;
				} else if (rd2p16.isSelected()) {
					p16 = 0;
				}
				if (rd1p17.isSelected() == true) {
					p17 = 1;
				} else if (rd2p17.isSelected()) {
					p17 = 0;
				}
				if (rd1p18.isSelected() == true) {
					p18 = 1;
				} else if (rd2p18.isSelected()) {
					p18 = 0;
				}
				if (rd1p19.isSelected() == true) {
					p19 = 1;
				} else if (rd2p19.isSelected()) {
					p19 = 0;
				}
				if (rd1p20.isSelected() == true) {
					p20 = 1;
				} else if (rd2p20.isSelected()) {
					p20 = 0;
				}
				if (rd1p21.isSelected() == true) {
					p21 = 1;
				} else if (rd2p21.isSelected()) {
					p21 = 0;
				}
				if (rd1p22.isSelected() == true) {
					p22 = 1;
				} else if (rd2p22.isSelected()) {
					p22 = 0;
				}
				if (rd1p23.isSelected() == true) {
					p23 = 1;
				} else if (rd2p23.isSelected()) {
					p23 = 0;
				}
				if (rd1p24.isSelected() == true) {
					p24 = 1;
				} else if (rd2p24.isSelected()) {
					p24 = 0;
				}
				if (rb1p25.isSelected() == true) {
					pv1 = 1;
				} else if (rb2p25.isSelected()) {
					pv1 = 0;
				}

				if (rb1p26.isSelected() == true) {
					pv2 = 1;
				} else if (rb2p26.isSelected()) {
					pv2 = 0;
				}

				if (rb1p27.isSelected() == true) {
					pv3 = 1;
				} else if (rb2p27.isSelected()) {
					pv3 = 0;
				}

				if (rb1p28.isSelected() == true) {
					pv4 = 1;
				} else if (rb2p28.isSelected()) {
					pv4 = 0;
				}

				if (rb1p29.isSelected() == true) {
					pv5 = 1;
				} else if (rb2p29.isSelected()) {
					pv5 = 0;
				}
				if (rb1p30.isSelected() == true) {
					pv6 = 1;
				} else if (rb2p30.isSelected()) {
					pv6 = 0;
				}
				if (rb1p31.isSelected() == true) {
					pv7 = 1;
				} else if (rb2p31.isSelected()) {
					pv7 = 0;
				}
				if (rb1p32.isSelected() == true) {
					pv8 = 1;
				} else if (rb2p32.isSelected()) {
					pv8 = 0;
				}
				if (rb1p33.isSelected() == true) {
					pv9 = 1;
				} else if (rb2p33.isSelected()) {
					pv9 = 0;
				}
				if (rb1p34.isSelected() == true) {
					pv10 = 1;
				} else if (rb2p34.isSelected()) {
					pv10 = 0;
				}
				if (rb1p35.isSelected() == true) {
					pv11 = 1;
				} else if (rb2p35.isSelected()) {
					pv11 = 0;
				}
				if (rb1p36.isSelected() == true) {
					pv12 = 1;
				} else if (rb2p36.isSelected()) {
					pv12 = 0;
				}
				if (rb1p37.isSelected() == true) {
					pv13 = 1;
				} else if (rb2p37.isSelected()) {
					pv13 = 0;
				}
				if (rb1p38.isSelected() == true) {
					pv14 = 1;
				} else if (rb2p38.isSelected()) {
					pv14 = 0;
				}
				if (rb1p39.isSelected() == true) {
					pv15 = 1;
				} else if (rb2p39.isSelected()) {
					pv15 = 0;
				}
				if (rb1p40.isSelected() == true) {
					pv16 = 1;
				} else if (rb2p40.isSelected()) {
					pv16 = 0;
				}
				if (rb1p41.isSelected() == true) {
					pv17 = 1;
				} else if (rb2p41.isSelected()) {
					pv17 = 0;
				}
				if (rb1p42.isSelected() == true) {
					pv18 = 1;
				} else if (rb2p42.isSelected()) {
					pv18 = 0;
				}
				if (rb1p43.isSelected() == true) {
					pv19 = 1;
				} else if (rb2p43.isSelected()) {
					pv19 = 0;
				}
				if (rb1p44.isSelected() == true) {
					pv20 = 1;
				} else if (rb2p44.isSelected()) {
					pv20 = 0;
				}

				if (nom.isEmpty() && ape.isEmpty()) {
					JOptionPane.showMessageDialog(null, "Error al validar", "Error", JOptionPane.ERROR_MESSAGE);
				} else {
					Estudiante e = new Estudiante();
					Controlador ecl = new Controlador();
					e.setNombres(txtnombres.getText());
					e.setApellidos(txtape.getText());
					e.setGrado((String) cmbGrado.getSelectedItem());
					e.setParalelo((String) cmbParalelo.getSelectedItem());
					try {
						ecl.validar(e, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18, p19,
								p20, p21, p22, p23, p24, pv1, pv2, pv3, pv4, pv5, pv6, pv7, pv8, pv9, pv10, pv11, pv12,
								pv13, pv14, pv15, pv16, pv17, pv18, pv19, pv20);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			}
		});
		btnNewButton.setIcon(new ImageIcon(Principal.class.getResource("/Imagenes/Button Check.png")));
		panel.add(btnNewButton, "flowy,cell 0 5 2 1,grow");

		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		contentPane.add(tabbedPane, BorderLayout.CENTER);

		JPanel panel_1 = new JPanel();
		tabbedPane.addTab("Conceptos Basicos", null, panel_1, null);
		panel_1.setLayout(new MigLayout("", "[90.00px,grow,fill][90.00,grow,fill]", "[16px,grow][grow][grow][grow][grow][grow][grow][grow][grow][grow][grow][grow][grow][grow][grow][grow][grow][grow][grow][grow][grow][grow][grow][grow]"));

		JLabel lblItem = new JLabel("Item 1:");
		lblItem.setHorizontalAlignment(SwingConstants.CENTER);
		lblItem.setFont(new Font("Dialog", Font.BOLD, 12));
		panel_1.add(lblItem, "cell 0 0,growx,aligny center");

		JLabel lblItem_1 = new JLabel("Item 13:");
		lblItem_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblItem_1.setFont(new Font("Dialog", Font.BOLD, 12));
		panel_1.add(lblItem_1, "cell 1 0,growx,aligny center");

		rd1p1 = new JRadioButton("SI");
		rd1p1.setHorizontalAlignment(SwingConstants.CENTER);
		bg1.add(rd1p1);
		panel_1.add(rd1p1, "flowx,cell 0 1,growx,aligny center");

		rd2p1 = new JRadioButton("NO");
		rd2p1.setHorizontalAlignment(SwingConstants.CENTER);
		bg1.add(rd2p1);
		panel_1.add(rd2p1, "cell 0 1,growx,aligny center");

		rd1p13 = new JRadioButton("SI");
		bg13.add(rd1p13);
		rd1p13.setHorizontalAlignment(SwingConstants.CENTER);
		panel_1.add(rd1p13, "flowx,cell 1 1,grow");

		JLabel lblItemMarca = new JLabel("Item 2:");
		lblItemMarca.setHorizontalAlignment(SwingConstants.CENTER);
		lblItemMarca.setFont(new Font("Dialog", Font.BOLD, 12));
		panel_1.add(lblItemMarca, "cell 0 2,grow");

		JLabel lblItem_2 = new JLabel("Item 14:");
		lblItem_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblItem_2.setFont(new Font("Dialog", Font.BOLD, 12));
		panel_1.add(lblItem_2, "cell 1 2,growx,aligny center");

		rd1p2 = new JRadioButton("SI");
		rd1p2.setHorizontalAlignment(SwingConstants.CENTER);
		bg2.add(rd1p2);
		panel_1.add(rd1p2, "flowx,cell 0 3,growx,aligny center");

		rd2p2 = new JRadioButton("NO");
		rd2p2.setHorizontalAlignment(SwingConstants.CENTER);
		bg2.add(rd2p2);
		panel_1.add(rd2p2, "cell 0 3,growx,aligny center");

		rd1p14 = new JRadioButton("SI");
		bg14.add(rd1p14);
		rd1p14.setHorizontalAlignment(SwingConstants.CENTER);
		panel_1.add(rd1p14, "flowx,cell 1 3,grow");

		rd2p14 = new JRadioButton("NO");
		bg14.add(rd2p14);
		rd2p14.setHorizontalAlignment(SwingConstants.CENTER);
		panel_1.add(rd2p14, "cell 1 3,grow");

		JLabel lblItemMarca_10 = new JLabel("Item 3:");
		lblItemMarca_10.setHorizontalAlignment(SwingConstants.CENTER);
		lblItemMarca_10.setFont(new Font("Dialog", Font.BOLD, 12));
		panel_1.add(lblItemMarca_10, "cell 0 4,growx,aligny center");

		JLabel lblItem_3 = new JLabel("Item 15");
		lblItem_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblItem_3.setFont(new Font("Dialog", Font.BOLD, 12));
		panel_1.add(lblItem_3, "cell 1 4,growx,aligny center");

		rd1p3 = new JRadioButton("SI");
		rd1p3.setHorizontalAlignment(SwingConstants.CENTER);
		bg3.add(rd1p3);
		panel_1.add(rd1p3, "flowx,cell 0 5,growx,aligny center");

		rd2p3 = new JRadioButton("NO");
		rd2p3.setHorizontalAlignment(SwingConstants.CENTER);
		bg3.add(rd2p3);
		panel_1.add(rd2p3, "cell 0 5,growx,aligny center");

		rd1p15 = new JRadioButton("SI");
		bg15.add(rd1p15);
		rd1p15.setHorizontalAlignment(SwingConstants.CENTER);
		panel_1.add(rd1p15, "flowx,cell 1 5,grow");

		JLabel lblItemMarca_1 = new JLabel("Item 4:");
		lblItemMarca_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblItemMarca_1.setFont(new Font("Dialog", Font.BOLD, 12));
		panel_1.add(lblItemMarca_1, "cell 0 6,growx,aligny center");

		JLabel lblItem_4 = new JLabel("Item 16:");
		lblItem_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblItem_4.setFont(new Font("Dialog", Font.BOLD, 12));
		panel_1.add(lblItem_4, "cell 1 6,grow");

		rd1p4 = new JRadioButton("SI");
		rd1p4.setHorizontalAlignment(SwingConstants.CENTER);
		bg4.add(rd1p4);
		panel_1.add(rd1p4, "flowx,cell 0 7,growx,aligny center");

		rd1p16 = new JRadioButton("SI");
		bg16.add(rd1p16);
		rd1p16.setHorizontalAlignment(SwingConstants.CENTER);
		panel_1.add(rd1p16, "flowx,cell 1 7,grow");

		JLabel lblItemMarca_2 = new JLabel("Item 5:");
		lblItemMarca_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblItemMarca_2.setFont(new Font("Dialog", Font.BOLD, 12));
		panel_1.add(lblItemMarca_2, "cell 0 8,growx,aligny center");

		JLabel lblItem_5 = new JLabel("Item 17:");
		lblItem_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblItem_5.setFont(new Font("Dialog", Font.BOLD, 12));
		panel_1.add(lblItem_5, "cell 1 8,growx,aligny center");

		rd1p5 = new JRadioButton("SI");
		rd1p5.setHorizontalAlignment(SwingConstants.CENTER);
		bg5.add(rd1p5);
		panel_1.add(rd1p5, "flowx,cell 0 9,growx,aligny center");

		rd1p17 = new JRadioButton("SI");
		bg17.add(rd1p17);
		rd1p17.setHorizontalAlignment(SwingConstants.CENTER);
		panel_1.add(rd1p17, "flowx,cell 1 9,grow");

		JLabel lblItemMarca_3 = new JLabel("Item 6:");
		lblItemMarca_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblItemMarca_3.setFont(new Font("Dialog", Font.BOLD, 12));
		panel_1.add(lblItemMarca_3, "cell 0 10,growx,aligny center");

		JLabel lblItem_6 = new JLabel("Item 18:");
		lblItem_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblItem_6.setFont(new Font("Dialog", Font.BOLD, 12));
		panel_1.add(lblItem_6, "cell 1 10,growx,aligny center");

		rd1p6 = new JRadioButton("SI");
		rd1p6.setHorizontalAlignment(SwingConstants.CENTER);
		bg6.add(rd1p6);
		panel_1.add(rd1p6, "flowx,cell 0 11,growx,aligny center");

		rd1p18 = new JRadioButton("SI");
		bg18.add(rd1p18);
		rd1p18.setHorizontalAlignment(SwingConstants.CENTER);
		panel_1.add(rd1p18, "flowx,cell 1 11,grow");

		JLabel lblItemMarca_4 = new JLabel("Item 7:");
		lblItemMarca_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblItemMarca_4.setFont(new Font("Dialog", Font.BOLD, 12));
		panel_1.add(lblItemMarca_4, "cell 0 12,growx,aligny center");

		JLabel lblItem_7 = new JLabel("Item 19:");
		lblItem_7.setHorizontalAlignment(SwingConstants.CENTER);
		lblItem_7.setFont(new Font("Dialog", Font.BOLD, 12));
		panel_1.add(lblItem_7, "cell 1 12,growx,aligny center");

		rd1p7 = new JRadioButton("SI");
		rd1p7.setHorizontalAlignment(SwingConstants.CENTER);
		bg7.add(rd1p7);
		panel_1.add(rd1p7, "flowx,cell 0 13,growx,aligny center");

		rd1p19 = new JRadioButton("SI");
		bg19.add(rd1p19);
		rd1p19.setHorizontalAlignment(SwingConstants.CENTER);
		panel_1.add(rd1p19, "flowx,cell 1 13,grow");

		JLabel lblItemMarca_5 = new JLabel("Item 8:");
		lblItemMarca_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblItemMarca_5.setFont(new Font("Dialog", Font.BOLD, 12));
		panel_1.add(lblItemMarca_5, "cell 0 14,growx,aligny center");

		JLabel lblItem_8 = new JLabel("Item 20:");
		lblItem_8.setHorizontalAlignment(SwingConstants.CENTER);
		lblItem_8.setFont(new Font("Dialog", Font.BOLD, 12));
		panel_1.add(lblItem_8, "cell 1 14,growx,aligny center");

		rd1p8 = new JRadioButton("SI");
		rd1p8.setHorizontalAlignment(SwingConstants.CENTER);
		bg8.add(rd1p8);
		panel_1.add(rd1p8, "flowx,cell 0 15,growx,aligny center");

		rd1p20 = new JRadioButton("SI");
		bg20.add(rd1p20);
		rd1p20.setHorizontalAlignment(SwingConstants.CENTER);
		panel_1.add(rd1p20, "flowx,cell 1 15,grow");

		JLabel lblItemMarca_6 = new JLabel("Item 9:");
		lblItemMarca_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblItemMarca_6.setFont(new Font("Dialog", Font.BOLD, 12));
		panel_1.add(lblItemMarca_6, "cell 0 16,growx,aligny center");

		JLabel lblItem_9 = new JLabel("Item 21:");
		lblItem_9.setHorizontalAlignment(SwingConstants.CENTER);
		lblItem_9.setFont(new Font("Dialog", Font.BOLD, 12));
		panel_1.add(lblItem_9, "cell 1 16,growx,aligny center");

		rd1p9 = new JRadioButton("SI");
		rd1p9.setHorizontalAlignment(SwingConstants.CENTER);
		bg9.add(rd1p9);
		panel_1.add(rd1p9, "flowx,cell 0 17,growx,aligny center");

		rd2p4 = new JRadioButton("NO");
		rd2p4.setHorizontalAlignment(SwingConstants.CENTER);
		bg4.add(rd2p4);
		panel_1.add(rd2p4, "cell 0 7,growx,aligny center");

		rd2p5 = new JRadioButton("NO");
		rd2p5.setHorizontalAlignment(SwingConstants.CENTER);
		bg5.add(rd2p5);
		panel_1.add(rd2p5, "cell 0 9,growx,aligny center");

		rd2p6 = new JRadioButton("NO");
		rd2p6.setHorizontalAlignment(SwingConstants.CENTER);
		bg6.add(rd2p6);
		panel_1.add(rd2p6, "cell 0 11,growx,aligny center");

		rd2p7 = new JRadioButton("NO");
		rd2p7.setHorizontalAlignment(SwingConstants.CENTER);
		bg7.add(rd2p7);
		panel_1.add(rd2p7, "cell 0 13,growx,aligny center");

		rd2p8 = new JRadioButton("NO");
		rd2p8.setHorizontalAlignment(SwingConstants.CENTER);
		bg8.add(rd2p8);
		panel_1.add(rd2p8, "cell 0 15,growx,aligny center");

		rd2p9 = new JRadioButton("NO");
		rd2p9.setHorizontalAlignment(SwingConstants.CENTER);
		bg9.add(rd2p9);
		panel_1.add(rd2p9, "cell 0 17,growx,aligny center");

		rd1p21 = new JRadioButton("SI");
		bg21.add(rd1p21);
		rd1p21.setHorizontalAlignment(SwingConstants.CENTER);
		panel_1.add(rd1p21, "flowx,cell 1 17,grow");

		JLabel lblItemMarca_8 = new JLabel("Item 10:");
		lblItemMarca_8.setHorizontalAlignment(SwingConstants.CENTER);
		lblItemMarca_8.setFont(new Font("Dialog", Font.BOLD, 12));
		panel_1.add(lblItemMarca_8, "cell 0 18,growx,aligny center");

		JLabel lblItem_10 = new JLabel("Item 22:");
		lblItem_10.setHorizontalAlignment(SwingConstants.CENTER);
		lblItem_10.setFont(new Font("Dialog", Font.BOLD, 12));
		panel_1.add(lblItem_10, "cell 1 18,growx,aligny center");

		rd1p10 = new JRadioButton("SI");
		rd1p10.setHorizontalAlignment(SwingConstants.CENTER);
		bg10.add(rd1p10);
		panel_1.add(rd1p10, "flowx,cell 0 19,growx,aligny center");

		rd1p22 = new JRadioButton("SI");
		bg22.add(rd1p22);
		rd1p22.setHorizontalAlignment(SwingConstants.CENTER);
		panel_1.add(rd1p22, "flowx,cell 1 19,grow");

		JLabel lblItemMarca_7 = new JLabel("Item 11:");
		lblItemMarca_7.setHorizontalAlignment(SwingConstants.CENTER);
		lblItemMarca_7.setFont(new Font("Dialog", Font.BOLD, 12));
		panel_1.add(lblItemMarca_7, "cell 0 20,growx,aligny center");

		JLabel lblItem_11 = new JLabel("Item 23:");
		lblItem_11.setHorizontalAlignment(SwingConstants.CENTER);
		lblItem_11.setFont(new Font("Dialog", Font.BOLD, 12));
		panel_1.add(lblItem_11, "cell 1 20,growx,aligny center");

		rd1p11 = new JRadioButton("SI");
		rd1p11.setHorizontalAlignment(SwingConstants.CENTER);
		bg11.add(rd1p11);
		panel_1.add(rd1p11, "flowx,cell 0 21,growx,aligny center");

		rd1p23 = new JRadioButton("SI");
		bg23.add(rd1p23);
		rd1p23.setHorizontalAlignment(SwingConstants.CENTER);
		panel_1.add(rd1p23, "flowx,cell 1 21,grow");

		JLabel lblItemMarca_9 = new JLabel("Item 12:");
		lblItemMarca_9.setHorizontalAlignment(SwingConstants.CENTER);
		lblItemMarca_9.setFont(new Font("Dialog", Font.BOLD, 12));
		panel_1.add(lblItemMarca_9, "cell 0 22,grow");

		JLabel lblItem_12 = new JLabel("Item 24:");
		lblItem_12.setHorizontalAlignment(SwingConstants.CENTER);
		lblItem_12.setFont(new Font("Dialog", Font.BOLD, 12));
		panel_1.add(lblItem_12, "cell 1 22,growx,aligny center");

		rd1p12 = new JRadioButton("SI");
		rd1p12.setHorizontalAlignment(SwingConstants.CENTER);
		bg12.add(rd1p12);
		panel_1.add(rd1p12, "flowx,cell 0 23,growx,aligny center");

		rd2p10 = new JRadioButton("NO");
		rd2p10.setHorizontalAlignment(SwingConstants.CENTER);
		bg10.add(rd2p10);
		panel_1.add(rd2p10, "cell 0 19,growx,aligny center");

		rd2p11 = new JRadioButton("NO");
		rd2p11.setHorizontalAlignment(SwingConstants.CENTER);
		bg11.add(rd2p11);
		panel_1.add(rd2p11, "cell 0 21,growx,aligny center");

		rd2p12 = new JRadioButton("NO");
		rd2p12.setHorizontalAlignment(SwingConstants.CENTER);
		bg12.add(rd2p12);
		panel_1.add(rd2p12, "cell 0 23,grow");

		rd2p13 = new JRadioButton("NO");
		bg13.add(rd2p13);
		rd2p13.setHorizontalAlignment(SwingConstants.CENTER);
		panel_1.add(rd2p13, "cell 1 1,grow");

		rd1p24 = new JRadioButton("SI");
		bg24.add(rd1p24);
		rd1p24.setHorizontalAlignment(SwingConstants.CENTER);
		panel_1.add(rd1p24, "flowx,cell 1 23,grow");

		rd2p15 = new JRadioButton("NO");
		bg15.add(rd2p15);
		rd2p15.setHorizontalAlignment(SwingConstants.CENTER);
		panel_1.add(rd2p15, "cell 1 5,grow");

		rd2p16 = new JRadioButton("NO");
		bg16.add(rd2p16);
		rd2p16.setHorizontalAlignment(SwingConstants.CENTER);
		panel_1.add(rd2p16, "cell 1 7,grow");

		rd2p17 = new JRadioButton("NO");
		bg17.add(rd2p17);
		rd2p17.setHorizontalAlignment(SwingConstants.CENTER);
		panel_1.add(rd2p17, "cell 1 9,grow");

		rd2p18 = new JRadioButton("NO");
		bg18.add(rd2p18);
		rd2p18.setHorizontalAlignment(SwingConstants.CENTER);
		panel_1.add(rd2p18, "cell 1 11,grow");

		rd2p19 = new JRadioButton("NO");
		bg19.add(rd2p19);
		rd2p19.setHorizontalAlignment(SwingConstants.CENTER);
		panel_1.add(rd2p19, "cell 1 13,grow");

		rd2p20 = new JRadioButton("NO");
		bg20.add(rd2p20);
		rd2p20.setHorizontalAlignment(SwingConstants.CENTER);
		panel_1.add(rd2p20, "cell 1 15,grow");

		rd2p21 = new JRadioButton("NO");
		bg21.add(rd2p21);
		rd2p21.setHorizontalAlignment(SwingConstants.CENTER);
		panel_1.add(rd2p21, "cell 1 17,grow");

		rd2p22 = new JRadioButton("NO");
		bg22.add(rd2p22);
		rd2p22.setHorizontalAlignment(SwingConstants.CENTER);
		panel_1.add(rd2p22, "cell 1 19,grow");

		rd2p23 = new JRadioButton("NO");
		bg23.add(rd2p23);
		rd2p23.setHorizontalAlignment(SwingConstants.CENTER);
		panel_1.add(rd2p23, "cell 1 21,grow");

		rd2p24 = new JRadioButton("NO");
		bg24.add(rd2p24);
		rd2p24.setHorizontalAlignment(SwingConstants.CENTER);
		panel_1.add(rd2p24, "cell 1 23,grow");

		JPanel panel_2 = new JPanel();
		tabbedPane.addTab("Percepci�n Visual", null, panel_2, null);
		panel_2.setLayout(new MigLayout("", "[grow][][grow]",
				"[grow,center][grow][grow][grow][grow][grow][grow][grow][grow][grow][grow][grow][grow][grow][grow][grow][grow][grow][grow][]"));

		JLabel lblItem_13 = new JLabel("Item 25:");
		lblItem_13.setFont(new Font("Dialog", Font.BOLD, 12));
		lblItem_13.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(lblItem_13, "cell 0 0,growx,aligny center");

		JLabel lblItem_23 = new JLabel("Item 35:");
		lblItem_23.setFont(new Font("Dialog", Font.BOLD, 12));
		lblItem_23.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(lblItem_23, "cell 2 0,growx,aligny center");

		rb1p25 = new JRadioButton("SI");
		bg25.add(rb1p25);
		rb1p25.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(rb1p25, "flowx,cell 0 1,growx,aligny center");

		rb1p35 = new JRadioButton("SI");
		bg35.add(rb1p35);
		rb1p35.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(rb1p35, "flowx,cell 2 1,growx,aligny center");

		JLabel lblItem_14 = new JLabel("Item 26:");
		lblItem_14.setFont(new Font("Dialog", Font.BOLD, 12));
		lblItem_14.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(lblItem_14, "cell 0 2,growx,aligny center");

		JLabel lblItem_24 = new JLabel("Item 36:");
		lblItem_24.setFont(new Font("Dialog", Font.BOLD, 12));
		lblItem_24.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(lblItem_24, "cell 2 2,growx,aligny center");

		rb1p26 = new JRadioButton("SI");
		bg26.add(rb1p26);
		rb1p26.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(rb1p26, "flowx,cell 0 3,growx,aligny center");

		rb1p36 = new JRadioButton("SI");
		bg36.add(rb1p36);
		rb1p36.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(rb1p36, "flowx,cell 2 3,growx,aligny center");

		JLabel lblItem_15 = new JLabel("Item 27:");
		lblItem_15.setFont(new Font("Dialog", Font.BOLD, 12));
		lblItem_15.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(lblItem_15, "cell 0 4,growx,aligny center");

		JLabel lblItem_25 = new JLabel("Item 37:");
		lblItem_25.setFont(new Font("Dialog", Font.BOLD, 12));
		lblItem_25.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(lblItem_25, "cell 2 4,growx,aligny center");

		rb1p27 = new JRadioButton("SI");
		bg27.add(rb1p27);
		rb1p27.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(rb1p27, "flowx,cell 0 5,growx,aligny center");

		rb1p37 = new JRadioButton("SI");
		bg37.add(rb1p37);
		rb1p37.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(rb1p37, "flowx,cell 2 5,growx,aligny center");

		JLabel lblItem_16 = new JLabel("Item 28:");
		lblItem_16.setFont(new Font("Dialog", Font.BOLD, 12));
		lblItem_16.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(lblItem_16, "cell 0 6,growx,aligny center");

		JLabel lblItem_26 = new JLabel("Item 38:");
		lblItem_26.setFont(new Font("Dialog", Font.BOLD, 12));
		lblItem_26.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(lblItem_26, "cell 2 6,growx,aligny center");

		rb1p28 = new JRadioButton("SI");
		bg28.add(rb1p28);
		rb1p28.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(rb1p28, "flowx,cell 0 7,growx,aligny center");

		rb1p38 = new JRadioButton("SI");
		bg38.add(rb1p38);
		rb1p38.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(rb1p38, "flowx,cell 2 7,growx,aligny center");

		JLabel lblItem_17 = new JLabel("Item 29:");
		lblItem_17.setFont(new Font("Dialog", Font.BOLD, 12));
		lblItem_17.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(lblItem_17, "cell 0 8,growx,aligny center");

		JLabel lblItem_27 = new JLabel("Item 39:");
		lblItem_27.setFont(new Font("Dialog", Font.BOLD, 12));
		lblItem_27.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(lblItem_27, "cell 2 8,growx,aligny center");

		rb1p29 = new JRadioButton("SI");
		bg29.add(rb1p29);
		rb1p29.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(rb1p29, "flowx,cell 0 9,growx,aligny center");

		rb1p39 = new JRadioButton("SI");
		bg39.add(rb1p39);
		rb1p39.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(rb1p39, "flowx,cell 2 9,growx,aligny center");

		JLabel lblItem_18 = new JLabel("Item 30:");
		lblItem_18.setFont(new Font("Dialog", Font.BOLD, 12));
		lblItem_18.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(lblItem_18, "cell 0 10,grow");

		JLabel lblItem_28 = new JLabel("Item 40:");
		lblItem_28.setFont(new Font("Dialog", Font.BOLD, 12));
		lblItem_28.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(lblItem_28, "cell 2 10,growx,aligny center");

		rb1p30 = new JRadioButton("SI");
		bg30.add(rb1p30);
		rb1p30.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(rb1p30, "flowx,cell 0 11,growx,aligny center");

		rb1p40 = new JRadioButton("SI");
		bg40.add(rb1p40);
		rb1p40.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(rb1p40, "flowx,cell 2 11,growx,aligny center");

		JLabel lblItem_19 = new JLabel("Item 31:");
		lblItem_19.setFont(new Font("Dialog", Font.BOLD, 12));
		lblItem_19.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(lblItem_19, "cell 0 12,growx,aligny center");

		JLabel lblItem_29 = new JLabel("Item 41:");
		lblItem_29.setFont(new Font("Dialog", Font.BOLD, 12));
		lblItem_29.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(lblItem_29, "cell 2 12,growx,aligny center");

		rb1p31 = new JRadioButton("SI");
		bg31.add(rb1p31);
		rb1p31.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(rb1p31, "flowx,cell 0 13,growx,aligny center");

		rb1p41 = new JRadioButton("SI");
		bg41.add(rb1p41);
		rb1p41.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(rb1p41, "flowx,cell 2 13,growx,aligny center");

		JLabel lblItem_20 = new JLabel("Item 32:");
		lblItem_20.setFont(new Font("Dialog", Font.BOLD, 12));
		lblItem_20.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(lblItem_20, "cell 0 14,growx,aligny center");

		JLabel lblItem_30 = new JLabel("Item 42:");
		lblItem_30.setFont(new Font("Dialog", Font.BOLD, 12));
		lblItem_30.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(lblItem_30, "cell 2 14,growx,aligny center");

		rb1p32 = new JRadioButton("SI");
		bg32.add(rb1p32);
		rb1p32.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(rb1p32, "flowx,cell 0 15,growx,aligny center");

		rb1p42 = new JRadioButton("SI");
		bg42.add(rb1p42);
		rb1p42.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(rb1p42, "flowx,cell 2 15,growx,aligny center");

		JLabel lblItem_21 = new JLabel("Item 33:");
		lblItem_21.setFont(new Font("Dialog", Font.BOLD, 12));
		lblItem_21.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(lblItem_21, "cell 0 16,growx,aligny center");

		JLabel lblItem_31 = new JLabel("Item 43:");
		lblItem_31.setFont(new Font("Dialog", Font.BOLD, 12));
		lblItem_31.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(lblItem_31, "cell 2 16,growx,aligny center");

		rb1p33 = new JRadioButton("SI");
		bg33.add(rb1p33);
		rb1p33.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(rb1p33, "flowx,cell 0 17,growx,aligny center");

		rb1p43 = new JRadioButton("SI");
		bg43.add(rb1p43);
		rb1p43.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(rb1p43, "flowx,cell 2 17,growx,aligny center");

		JLabel lblItem_22 = new JLabel("Item 34:");
		lblItem_22.setFont(new Font("Dialog", Font.BOLD, 12));
		lblItem_22.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(lblItem_22, "cell 0 18,growx,aligny center");

		JLabel lblItem_32 = new JLabel("Item 44:");
		lblItem_32.setFont(new Font("Dialog", Font.BOLD, 12));
		lblItem_32.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(lblItem_32, "cell 2 18,growx,aligny center");

		rb2p25 = new JRadioButton("NO");
		bg25.add(rb2p25);
		rb2p25.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(rb2p25, "cell 0 1,growx,aligny center");

		rb2p26 = new JRadioButton("NO");
		bg26.add(rb2p26);
		rb2p26.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(rb2p26, "cell 0 3,growx,aligny center");

		rb1p34 = new JRadioButton("SI");
		bg34.add(rb1p34);
		rb1p34.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(rb1p34, "flowx,cell 0 19,growx,aligny center");

		rb2p27 = new JRadioButton("NO");
		bg27.add(rb2p27);
		rb2p27.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(rb2p27, "cell 0 5,growx,aligny center");

		rb2p28 = new JRadioButton("NO");
		bg28.add(rb2p28);
		rb2p28.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(rb2p28, "cell 0 7,growx,aligny center");

		rb2p29 = new JRadioButton("NO");
		bg29.add(rb2p29);
		rb2p29.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(rb2p29, "cell 0 9,growx,aligny center");

		rb2p30 = new JRadioButton("NO");
		bg30.add(rb2p30);
		rb2p30.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(rb2p30, "cell 0 11,growx,aligny center");

		rb2p31 = new JRadioButton("NO");
		bg31.add(rb2p31);
		rb2p31.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(rb2p31, "cell 0 13,growx,aligny center");

		rb2p32 = new JRadioButton("NO");
		bg32.add(rb2p32);
		rb2p32.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(rb2p32, "cell 0 15,growx,aligny center");

		rb2p33 = new JRadioButton("NO");
		bg33.add(rb2p33);
		rb2p33.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(rb2p33, "cell 0 17,growx,aligny center");

		rb2p34 = new JRadioButton("NO");
		bg34.add(rb2p34);
		rb2p34.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(rb2p34, "cell 0 19,growx,aligny center");

		rb1p44 = new JRadioButton("SI");
		bg44.add(rb1p44);
		rb1p44.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(rb1p44, "flowx,cell 2 19,growx,aligny center");

		rb2p35 = new JRadioButton("NO");
		bg35.add(rb2p35);
		rb2p35.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(rb2p35, "cell 2 1,growx,aligny center");

		rb2p36 = new JRadioButton("NO");
		bg36.add(rb2p36);
		rb2p36.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(rb2p36, "cell 2 3,growx,aligny center");

		rb2p37 = new JRadioButton("NO");
		bg37.add(rb2p37);
		rb2p37.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(rb2p37, "cell 2 5,growx,aligny center");

		rb2p38 = new JRadioButton("NO");
		bg38.add(rb2p38);
		rb2p38.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(rb2p38, "cell 2 7,growx,aligny center");

		rb2p39 = new JRadioButton("NO");
		bg39.add(rb2p39);
		rb2p39.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(rb2p39, "cell 2 9,growx,aligny center");

		rb2p40 = new JRadioButton("NO");
		bg40.add(rb2p40);
		rb2p40.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(rb2p40, "cell 2 11,growx,aligny center");

		rb2p41 = new JRadioButton("NO");
		bg41.add(rb2p41);
		rb2p41.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(rb2p41, "cell 2 13,growx,aligny center");

		rb2p42 = new JRadioButton("NO");
		bg42.add(rb2p42);
		rb2p42.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(rb2p42, "cell 2 15,growx,aligny center");

		rb2p43 = new JRadioButton("NO");
		bg43.add(rb2p43);
		rb2p43.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(rb2p43, "cell 2 17,growx,aligny center");

		rb2p44 = new JRadioButton("NO");
		bg44.add(rb2p44);
		rb2p44.setHorizontalAlignment(SwingConstants.CENTER);
		panel_2.add(rb2p44, "cell 2 19,growx,aligny center");

		JPanel panel_3 = new JPanel();
		contentPane.add(panel_3, BorderLayout.NORTH);
		panel_3.setLayout(new BorderLayout(0, 0));

		JLabel lblTestDePrecalculo = new JLabel("TEST DE PRECALCULO");
		panel_3.add(lblTestDePrecalculo, BorderLayout.NORTH);
		lblTestDePrecalculo.setHorizontalAlignment(SwingConstants.CENTER);
		lblTestDePrecalculo.setVerticalAlignment(SwingConstants.TOP);
		lblTestDePrecalculo.setIcon(new ImageIcon(Principal.class.getResource("/Imagenes/Document Checklist.png")));
		lblTestDePrecalculo.setFont(new Font("Segoe UI", Font.BOLD, 20));

		JLabel lblNewLabel_3 = new JLabel(
				"Para evaluar el desarrollo de razonamiento matem\u00E1tico en ni\u00F1os de 4 a 7");
		lblNewLabel_3.setFont(new Font("Dialog", Font.PLAIN, 14));
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		panel_3.add(lblNewLabel_3, BorderLayout.CENTER);

		JLabel lblNewLabel_4 = new JLabel("Neva Milicic M & Sandra Schmidt M");
		lblNewLabel_4.setFont(new Font("Dialog", Font.PLAIN, 13));
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		panel_3.add(lblNewLabel_4, BorderLayout.SOUTH);
	}
}
