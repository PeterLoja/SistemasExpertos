package Manejo;

import java.io.FileOutputStream;

import javax.swing.JOptionPane;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.DefaultPieDataset;

import com.itextpdf.text.Document;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

import CLIPSJNI.*;
import Modelo.Estudiante;

public class Controlador {

	private Environment clips;

	public Controlador() {

		clips = new Environment();
		clips.load("estudiante.clp");
		clips.reset();
		clips.run();
	}

	public void validar(Estudiante e, int p1, int p2, int p3, int p4, int p5, int p6, int p7, int p8, int p9, int p10,
			int p11, int p12, int p13, int p14, int p15, int p16, int p17, int p18, int p19, int p20, int p21, int p22,
			int p23, int p24, int pv1, int pv2, int pv3, int pv4, int pv5, int pv6, int pv7, int pv8, int pv9, int pv10,
			int pv11, int pv12, int pv13, int pv14, int pv15, int pv16, int pv17, int pv18, int pv19, int pv20) throws Exception {

		clips.reset();

		clips.eval("(assert (Estudiante            \n" + "    (nombres \"" + e.getNombres() + "\")\n"
				+ "    (apellidos \"" + e.getApellidos() + "\")\n" + "    (grado \"" + e.getGrado() + "\")\n"
				+ "    (paralelo \"" + e.getParalelo() + "\")\n" + "	)\n" + ")");

		clips.eval("(facts)");

		clips.eval("(assert (CB           \n" + "    (cb1 " + p1 + ")\n" + "    (cb2 " + p2 + ")\n" + "    (cb3 " + p3
				+ ")\n" + "    (cb4 " + p4 + ")\n" + "    (cb5 " + p5 + ")\n" + "    (cb6 " + p6 + ")\n" + "    (cb7 "
				+ p7 + ")\n" + "    (cb8 " + p8 + ")\n" + "    (cb9 " + p9 + ")\n" + "    (cb10 " + p10 + ")\n"
				+ "    (cb11 " + p11 + ")\n" + "    (cb12 " + p12 + ")\n" + "    (cb13 " + p13 + ")\n" + "    (cb14 "
				+ p14 + ")\n" + "    (cb15 " + p15 + ")\n" + "    (cb16 " + p16 + ")\n" + "    (cb17 " + p17 + ")\n"
				+ "    (cb18 " + p18 + ")\n" + "    (cb19 " + p19 + ")\n" + "    (cb20 " + p20 + ")\n" + "    (cb21 "
				+ p21 + ")\n" + "    (cb22 " + p22 + ")\n" + "    (cb23 " + p23 + ")\n" + "    (cb24 " + p24 + ")\n"
				+ "	)\n" + ")");

		clips.eval("(facts)");

		clips.eval("(assert (PV           \n" + "    (pv1 " + pv1 + ")\n" + "    (pv2 " + pv2 + ")\n" + "    (pv3 "
				+ pv3 + ")\n" + "    (pv4 " + pv4 + ")\n" + "    (pv5 " + pv5 + ")\n" + "    (pv6 " + pv6 + ")\n"
				+ "    (pv7 " + pv7 + ")\n" + "    (pv8 " + pv8 + ")\n" + "    (pv9 " + pv9 + ")\n" + "    (pv10 "
				+ pv10 + ")\n" + "    (pv11 " + pv11 + ")\n" + "    (pv12 " + pv12 + ")\n" + "    (pv13 " + pv13 + ")\n"
				+ "    (pv14 " + pv14 + ")\n" + "    (pv15 " + pv15 + ")\n" + "    (pv16 " + pv16 + ")\n" + "    (pv17 "
				+ pv17 + ")\n" + "    (pv18 " + pv18 + ")\n" + "    (pv19 " + pv19 + ")\n" + "    (pv20 " + pv20 + ")\n"
				+ "	)\n" + ")");

		clips.eval("(facts)");

		clips.run();

		String evaluar = "(find-all-facts ((?r Resultado)) TRUE)";
		PrimitiveValue value = clips.eval(evaluar);
		String Nombre = value.get(0).getFactSlot("nombre").toString();

		String evaluar1 = "(find-all-facts ((?r Resultado )) TRUE)";
		PrimitiveValue value1 = clips.eval(evaluar1);
		String PuntajeCB = value1.get(0).getFactSlot("puntajecb").toString();

		String evaluar2 = "(find-all-facts ((?r Resultado )) TRUE)";
		PrimitiveValue value2 = clips.eval(evaluar1);
		String PuntajePV = value2.get(0).getFactSlot("puntajepv").toString();
		
		String evaluar3 = "(find-all-facts ((?r Resultado )) TRUE)";
		PrimitiveValue value3 = clips.eval(evaluar1);
		String PuntajeF = value3.get(0).getFactSlot("puntajeF").toString();

		JOptionPane.showMessageDialog(null, "EL Estudiante: "+ Nombre + " ha respondido correctamente en un " + PuntajeF +"% el test", "Informacion", JOptionPane.INFORMATION_MESSAGE);

		clips.eval("(facts)");
		
		graficar(PuntajeF);
		
		generarpdf(Nombre,PuntajeCB,PuntajePV,PuntajeF);
	}

	private void graficar(String puntajeF) {
		double val=Double.parseDouble(puntajeF);
		DefaultPieDataset data = new DefaultPieDataset();
		data.setValue("Estudiante", val);
		data.setValue("Total",100);
		// Creando el Grafico
        JFreeChart chart = ChartFactory.createPieChart(
         "PORCENTAJE DEL TEST", 
         data, 
         true,
         true,
         false);
        
        ChartFrame frame = new ChartFrame("JFreeChart", chart);
        frame.pack();
        frame.setVisible(true);
	}

	private void generarpdf(String nombre, String puntajeCB, String puntajePV, String puntajeF) {
		try {
		Document document=new Document();
		PdfWriter.getInstance(document, new FileOutputStream("E:\\Universidad\\Noveno Ciclo\\SIstemas Expertos\\Clips\\ProyectoSE\\Reglas.pdf"));
		document.open();
		document.addTitle("Sistema Experto");
		document.add(new Paragraph("Se registrado un hecho en Estudiantes"));
		document.add(new Paragraph("Se registrado un hecho en Conceptos Basicos"));
		document.add(new Paragraph("Se registrado un hecho en Percepcion Visual"));
		document.add(new Paragraph("Se despira Reglas"));
		document.add(new Paragraph("Se modifica el hecho en tiempo real"));
		document.add(new Paragraph("El resultado para "+nombre+" es "+puntajeF));
		document.add(new Paragraph("Obteniendo en cada seccion "+puntajeCB+" y "+puntajePV));
		document.close();
		}catch (Exception e) {
			System.out.println(e);
		}
		}
	}